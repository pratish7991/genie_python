import psycopg2

class Connection:
    database_name='genie'
    database_user='postgres'
    database_password='25996'
    database_host='localhost'
    port_id=5432
    try:
        conn = psycopg2.connect(
            host=database_host,
            dbname=database_name,
            user=database_user,
            password=database_password,
            port=port_id)

    except Exception as error:
        print(error)


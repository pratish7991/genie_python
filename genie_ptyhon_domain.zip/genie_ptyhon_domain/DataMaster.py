import openpyxl

import Global_vars
import Query


class DataMaster:
    def __init__(self,Data_Master_ID,Data_Summary_ID,Data_Parameter_No,Data_Parameter_Name,Data_Parameter_Types):
        self.Data_Master_ID = Data_Master_ID
        self.Data_Summary_ID=Data_Summary_ID
        self.Data_Parameter_No=Data_Parameter_No
        self.Data_Parameter_Name=Data_Parameter_Name
        self.Data_Parameter_Types=Data_Parameter_Types

    def __str__(self):
        return "Data_Master_ID= {}, Data_Parameter_No= {}, Data_Parameter_Name= {}, Data_Parameter_Types ={}".format(self.Data_Master_ID,self.Data_Parameter_No,self.Data_Parameter_Name,self.Data_Parameter_Types)

    @staticmethod
    def insertData():
        C = []
        A = Global_vars.GEINE_DATA["TBL_DATA_MASTER"]
        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                C.append(DataMaster(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value,
                                 A.cell(i + 3, 4).value,A.cell(i+3,5).value))
                i += 1
            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_DATA_MASTER", C[i].Data_Master_ID, C[i].Data_Summary_ID,C[i].Data_Parameter_No, C[i].Data_Parameter_Name,
                                           C[i].Data_Parameter_Types)

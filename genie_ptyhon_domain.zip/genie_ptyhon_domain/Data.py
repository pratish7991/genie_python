import openpyxl

import Global_vars
import Query


class Data:
    @staticmethod
    def insertData():
        for k in range(len(Global_vars.Data_SUMMARY_ID)):

            A = Global_vars.GEINE_DATA[f"{Global_vars.Data_Table_Name[k][0]}"]
            n=0
            while (Data.checkData(n,k)):
                C = []
                for i in range(len(Global_vars.Data_Parameter_Name[k])+1):

                    if type(A.cell(3+n, (1 + i)).value) == str:
                        C.append(A.cell(3 + n, (1 + i)).value.strip())
                    else:
                        C.append(A.cell(3 + n, (1 + i)).value)

                Global_vars.Data_Insert_Table=k
                Query.insertTable("TBL_DATA",*C)
                n+=1

    @staticmethod
    def checkData(i,k):
        A = Global_vars.GEINE_DATA[f"{Global_vars.Data_Table_Name[k][0]}"]
        if A.cell(i + 3, 1).value is not None:
            return True
        else:
            return False

import Global_vars
import Query
import pandas as pd
from Connection import Connection
from sqlalchemy import create_engine
from Extraction import Extraction

class ContextMapping:
    @staticmethod
    def createContextMappingTable():
        mycursor = Connection.conn.cursor()
        mycursor.execute(Global_vars.sql_commands_select[2])
        table = mycursor.fetchall()
        column_names = [i[0] for i in mycursor.description]
        Global_vars.context_maaping_table = pd.DataFrame(table, columns=column_names)
        Global_vars.context_maaping_table.index += 1
        Global_vars.context_maaping_table.index.name = "Context_Mapping_Id"
        Global_vars.context_maaping_table["context_rule_Id"] = 0

    @staticmethod
    def getContextMappingTable():
        return Global_vars.context_maaping_table[["feature_id", "context_id", "data_summary_id", "data_parameter_no", "context_rule_Id"]]

    @staticmethod
    def sortContextMappigTable(*context_id):
        if (len(list(context_id))==0):
            Global_vars.user_context_maaping_table=Global_vars.context_maaping_table
            pass
        else :
            Global_vars.user_context_maaping_table = Global_vars.context_maaping_table[Global_vars.context_maaping_table["context_id"].isin(list(context_id))]
        Extraction.extractResult()

    @staticmethod
    def ruleInsertion(context_mapping_id,*rule_number):
        Global_vars.context_maaping_table["context_rule_Id"] = Global_vars.context_maaping_table["context_rule_Id"].astype('object')
        a=list(rule_number)
        Global_vars.context_maaping_table.at[context_mapping_id, "context_rule_Id"]=a

    @staticmethod
    def setContextMappingToDataBase():
        conn_string = 'postgresql://postgres:25996@localhost:5432/pratish6'
        db = create_engine(conn_string)
        conn = db.connect()
        Global_vars.context_maaping_table[["feature_id", "context_id", "data_summary_id", "data_parameter_no", "context_rule_Id"]].to_sql('TBL_Context_Mapping', con=conn, if_exists='replace', index=True)
        conn.autocommit = True
        conn.close()









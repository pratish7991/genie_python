import itertools

import openpyxl
import Connection
import Global_vars
import pandas as pd

def createTable(*TBL_NAME):
    mycursor = Connection.Connection.conn.cursor()
    fd = open('Create_Table.sql', 'r')
    sqlFile = fd.read()
    fd.close()
    sqlCommands = list(sqlFile.split(';'))
    A = list(TBL_NAME)
    for q in A:
        # try:
        if (q != "TBL_DATA"):
            mycursor.execute(sqlCommands[Global_vars.Table[q]])
            Connection.Connection.conn.commit()
        else:
            for k in range(len(Global_vars.Data_SUMMARY_ID)):
                h = sqlCommands[Global_vars.Table[q]]
                h+=","
                for j in range(len(Global_vars.Data_Parameter_Name[k])):
                    h += Global_vars.Data_Parameter_Name[k][j]+" "+Global_vars.Data_Parameter_Types[k][j]
                    if ((j+1)==len(Global_vars.Data_Parameter_Name[k])):
                        break
                    h += ", "
                h += " )"
                mycursor.execute(h)
                Connection.Connection.conn.commit()
                mycursor.execute("ALTER TABLE TBL_DATA RENAME TO " + Global_vars.Data_Table_Name[k][0] + "")
                Connection.Connection.conn.commit()
        # except Exception as e:
        #     print("e")


def insertTable(Table_Name, *Table_Parameter_value):
    mycursor = Connection.Connection.conn.cursor()
    fd = open('Insert_Table.sql', 'r')
    sqlFile = fd.read()
    fd.close()
    sqlCommands = list(sqlFile.split(';'))
    A = list(Table_Parameter_value)
    # try :
    if (Global_vars.Table[Table_Name] == 0) :
        mycursor.execute(sqlCommands[Global_vars.Table[Table_Name]], (
                         str(A[0]), str(A[1]) , str(A[2])))

    elif ((Global_vars.Table[Table_Name] == 1) or (Global_vars.Table[Table_Name] == 2) or (
            Global_vars.Table[Table_Name] == 3) or (Global_vars.Table[Table_Name] == 6)):

        mycursor.execute(sqlCommands[Global_vars.Table[Table_Name]] ,(
                         str(A[0]) ,str(A[1]) ,str(A[2]),str(A[3])))
    elif (Global_vars.Table[Table_Name] == 4):
        mycursor.execute(sqlCommands[Global_vars.Table[Table_Name]] ,(""+
                         str(A[0])+"","" + str(A[1]) + "","" + str(A[2]) + "","" + str(A[3]) + "","" + str(
            A[4]) + ""))
    else:

        h = sqlCommands[Global_vars.Table["TBL_DATA"]]
        h += " "
        h += Global_vars.Data_Table_Name[Global_vars.Data_Insert_Table][0]
        h += "( "
        h += "DATA_ID, "
        mycursor = Connection.Connection.conn.cursor()


        for j in range(len(Global_vars.Data_Parameter_Name[Global_vars.Data_Insert_Table])):
            h += Global_vars.Data_Parameter_Name[Global_vars.Data_Insert_Table][j]
            if ((j + 1) == len(Global_vars.Data_Parameter_Name[Global_vars.Data_Insert_Table])):
                break
            h += ", "
        h += " )"
        h += " VALUES( "

        for i in range(len(A)):
            h += "'" +str(A[i]) + "'"
            if ((i + 1) == len(A)):
                break
            h += ", "
        h += ")"
        mycursor.execute(h)
        Connection.Connection.conn.commit()


    Connection.Connection.conn.commit()
    # except Exception as e:
    #     print(e)




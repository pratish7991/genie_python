import openpyxl

import Global_vars
import Query


class DataSummary:
    def __init__(self,Data_Summary_ID,Context_ID,Number_of_columns,Tbl_Name):
        self.Data_Summary_ID=Data_Summary_ID
        self.Context_ID=Context_ID
        self.Number_of_colummns=Number_of_columns
        self.Tbl_Name=Tbl_Name

    def __str__(self):
        return f"Data_Summary_ID = {self.Data_Summary_ID}, Number_of_columns = {self.Number_of_colummns}, Tbl_Name = {self.Tbl_Name}"

    @staticmethod
    def insertData():
        C = []
        A = Global_vars.GEINE_DATA["TBL_DATA_SUMMARY"]
        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                C.append(DataSummary(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value,A.cell(i + 3, 4).value))
                i += 1
            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_DATA_SUMMARY", C[i].Data_Summary_ID, C[i].Context_ID,C[i].Number_of_colummns,C[i].Tbl_Name)
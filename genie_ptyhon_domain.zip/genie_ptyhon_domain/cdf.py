from sqlalchemy import create_engine
from Connection1 import Connection
import Global_vars
import pandas as pd
# conn_string = 'postgresql://postgres:25996@localhost:5432/CDF'
# db = create_engine(conn_string)
# conn = db.connect()
# mycursor = Connection.conn.cursor()

# mycursor.execute("")
# table = mycursor.fetchall()
# field_names = [i[0] for i in mycursor.description]
# Data_Table = pd.DataFrame(table, columns=field_names)


Result_Table= pd.read_csv('cognite-IFSDB-assets.csv')

print(Result_Table.columns)
Result_Table["externalId"]=Result_Table["loc"]+"Pratish1997"

Result_Table["parentExternalId"]=Result_Table["parent_loc"]+"Pratish1997"
Result_Table["name"]=Result_Table["lastUpdatedTime"]


# Result_Table.rename(columns = {'info':'description'}, inplace = True)
# Result_Table.rename(columns = {'tag':'name'}, inplace = True)
#
Result_Table.to_csv('Assets.csv')

# print(Result_Table)
# Result_Table.to_sql('Timeseries', con=conn, if_exists='replace', index=True)
# conn.autocommit = True
# conn.close()
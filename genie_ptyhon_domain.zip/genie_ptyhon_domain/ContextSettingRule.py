import pandas as pd
import RuleEnigne


class ContextSettingRule:

    @staticmethod
    def allRules(Result_Table,Rule_key):

        """
        :param Extracted_DF: Dataframe in which we apply the rules
        :param Column_Name: Name of data frame columns we apply the rules
        :param Rule_key: Rule type sequenced by rule key, this will determine the type of rule we applied to the dataframe
        :return: This function will the applied rules data frame
        """

        Result_Table1 = Result_Table.copy()
        columns = list(Result_Table1.columns)
        # print(columns)
        columns = list(Result_Table1.columns)
        for a, b in enumerate(columns):
            print(b)
            if Rule_key[a] == 2:
                for i in Result_Table1[b]:
                    print(i)
                    print(Result_Table1[b])
                    Result_Table1 = Result_Table1.replace(i, list(i)[0])

            elif (Rule_key[a] == 1):
                a = {}
                for i, j in enumerate(Result_Table1[b]):
                    print(i)
                    print(Result_Table1[b].values[i])
                    print(type(int(Result_Table1[b].values[i])))
                    a[b.lower().strip()] = int(Result_Table1[b].values[i])
                    for k, l in RuleEnigne.rule_age.items():
                        if (k).matches(a):
                            print(l)
                            Result_Table1[b] = Result_Table1[b].replace(int(Result_Table1[b].values[i]), l)
                    a = {}

        return Result_Table1
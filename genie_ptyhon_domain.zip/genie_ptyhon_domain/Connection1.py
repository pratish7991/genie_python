import psycopg2

class Connection:
    hostname='localhost'
    database='CDF'
    username='postgres'
    pwd='25996'
    port_id=5432
    try:
        conn = psycopg2.connect(
            host=hostname,
            dbname=database,
            user=username,
            password=pwd,
            port=port_id)

    except Exception as error:
        print(error)


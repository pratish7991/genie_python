import rule_engine

# Rule 2
# rule_stringToChar = {
#     rule_engine.Rule('gender == "Male"'): ['gender', 'M'],
#     rule_engine.Rule('gender =="Female"'): ['gender', 'F'],
#     rule_engine.Rule('age == "Young"'): ['age', 'Y'],
#     rule_engine.Rule('age == "Old"'): ['age', 'O'],
#     rule_engine.Rule('age == "Adult"'): ['age', 'A']
# }

# Rule 1
#Write everything in lower case
rule_age = {
    rule_engine.Rule('age <= 12'): 'Teen',
    rule_engine.Rule('age > 12 and age<=24'): 'Young',
    rule_engine.Rule('age > 24 and age<=50'): 'Adult',
    rule_engine.Rule('age > 50 and age<=80'): 'Old'
}

import Global_vars
from Connection import Connection
import pandas as pd

from ContextSettingRule import ContextSettingRule

class Extraction:
    @staticmethod
    def extractResult():
        from sqlalchemy import create_engine
        conn_string = 'postgresql://postgres:25996@localhost:5432/pratish6'
        db = create_engine(conn_string)
        conn = db.connect()
        mycursor = Connection.conn.cursor()

        for i, valuei in enumerate(Global_vars.user_context_maaping_table["context_id"].unique()):
            user_context_maaping_table_with_context_id = Global_vars.user_context_maaping_table[Global_vars.user_context_maaping_table["context_id"] == valuei]

            for j, valuej in enumerate(user_context_maaping_table_with_context_id["data_summary_id"].unique()):
                user_context_maaping_table_with_data_summary_id  = user_context_maaping_table_with_context_id[user_context_maaping_table_with_context_id["data_summary_id"] == valuej]
                
                TableName = list(user_context_maaping_table_with_data_summary_id["tbl_name"].unique())
                Rule_key = list(user_context_maaping_table_with_data_summary_id["context_rule_Id"])
                Dataparametername = list(user_context_maaping_table_with_data_summary_id["data_parameter_name"])
                Dataparametername=list(map(lambda x: x.lower().strip(),Dataparametername))
                print(TableName)
                mycursor.execute(Global_vars.sql_commands_select[0].format(TableName[0]))
                table = mycursor.fetchall()
                field_names = [i[0] for i in mycursor.description]
                Data_Table = pd.DataFrame(table, columns=field_names)

                G=Data_Table[Data_Table.columns.intersection(Dataparametername)]

                print(G)


                for k, valuek in enumerate(Rule_key):
                    if (type(Rule_key[k]) is list):
                        H=ContextSettingRule.allRules(G,Rule_key[k])
                        G=H
                    else:
                        H=G
                        G=H

                Result_Table = G
                Result_Table.index.name = "result_id"
                Result_Table.index += 1

                ResultTableName = 'TBL_Result' + f'_{i + 1}' + f'_{valuej}'
                Result_Table.to_sql(ResultTableName, con=conn, if_exists='replace', index=True)
        conn.autocommit = True
        conn.close()

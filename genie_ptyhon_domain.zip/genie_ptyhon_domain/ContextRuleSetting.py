import openpyxl

import Global_vars
import Query
# A contextrulesetting class with table column name as its parameters
class ContextRuleSetting:
    def __init__(self,Context_Rule_ID,Rule_Name,Rule_Logic,Rule_Discription):
        self.Context_Rule_ID=Context_Rule_ID
        self.Rule_Name=Rule_Name
        self.Rule_Logic=Rule_Logic
        self.Rule_Discription=Rule_Discription

    def __str__(self):
        return "Context_Rule_ID = {}, Rule_Name = {}, Rule_Logic = {}, Rule_Discription = {}".format(self.Context_Rule_ID,self.Rule_Name,self.Rule_Logic,self.Rule_Discription)


    # This method extract data of context from excel file and store it into an object and then upload its elements of this object in postgres sql
    @staticmethod
    def insertData():
        C = []
        A = Global_vars.GEINE["TBL_CONTEXT_SETTING_RULE"]

        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                C.append(ContextRuleSetting(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value,
                                 A.cell(i + 3, 4).value))
                i += 1
            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_CONTEXT_SETTING_RULE", C[i].Context_Rule_ID, C[i].Rule_Name, C[i].Rule_Logic,
                                           C[i].Rule_Discription)

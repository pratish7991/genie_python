INSERT INTO TBL_DOMAIN(Domain_ID,Domain_Name,Domain_Description) VALUES (%s,%s,%s) ;
INSERT INTO TBL_CONTEXT(Context_ID ,Domain_ID ,Context_Name,Context_Discription) VALUES (%s,%s,%s,%s) ;
INSERT INTO TBL_FEATURES(Feature_ID,Domain_ID,Feature_Name,Feature_Description) VALUES (%s,%s,%s,%s);
INSERT INTO TBL_CONTEXT_RULE_SETTING(Context_Rule_ID, Rule_Name, Rule_Logic, Rule_Description) VALUES (%s,%s,%s,%s);
INSERT INTO TBl_DATA_MASTER(Data_Master_ID,DATA_SUMMARY_ID , Data_Parameter_No , Data_Parameter_Name , Data_Parameter_Types) VALUES (%s,%s,%s,%s,%s) ;
INSERT INTO  ;
INSERT INTO TBL_DATA_SUMMARY(DATA_SUMMARY_ID,CONTEXT_ID,NUMBER_OF_COLUMNS,TBL_NAME) VALUES (%s,%s,%s,%s);
INSERT INTO TBL_RESULT_MASTER(Result_Master_ID, Result_Master_No, Result_Master_Name) VALUES (%s,%s,%s);
INSERT INTO TBL_RESULT(Result_ID,Age,Music_Listen) VALUES (%s,%s,%s);

import openpyxl

import Query

# A domain class
class Domain:
    def __init__(self,Domain_ID,Domain_Name,Domain_Description):
        self.Domain_ID=Domain_ID
        self.Domain_Name=Domain_Name
        self.Domain_Description=Domain_Description

    def __str__(self):
        "Domain_ID=+{}, Domain_Name= {}, Domain_Description= {}".format(self.Domain_ID,self.Domain_Name,self.Domain_Description)

    @staticmethod
    def insertData():
        C = []
        TBL_GEINE = openpyxl.load_workbook("TBL_GEINE.xlsx")
        A = TBL_GEINE["TBL_DOMAIN"]
        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                C.append(Domain(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value))
                i += 1
            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_DOMAIN", C[i].Domain_ID, C[i].Domain_Name, C[i].Domain_Description)



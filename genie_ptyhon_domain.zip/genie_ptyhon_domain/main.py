# import Connection
import ParameterStep3
from Context import Context
from ContextRuleSetting import ContextRuleSetting
from DataMaster import DataMaster
from  Domain import Domain
from Feature import Feature
import Global_vars
import Query
import xlrd
import openpyxl
from psycopg2 import sql
import pandas as pd
from psycopg2.extensions import AsIs
from ContextMapping import ContextMapping
from ContextSettingRule import ContextSettingRule
from Data import Data
from DataSummary import DataSummary
from Extraction import Extraction




"""
Sequence of Model Execution 
Creation
1.Create Domain Table, Feature Table, Context Table, Rule Setting Table 
    e.g Query.createTable("TBL_DOMAIN","TBL_FEATURES","TBL_CONTEXT","TBL_CONTEXT_SETTING_RULE")
2.Insert into Domain Table, Feature Table, Context Table, Rule Setting Table 
    e.g. Domain.insertData()
    Feature.insertData()
    Context.insertData()
    ContextRuleSetting.insertData()
3.Create Data Master Table, Data Summary Table 
    e.g 
    Query.createTable("TBL_DATA_MASTER","TBL_DATA_SUMMARY")

4.Insert into Data Master Table, Data Summary Table 
    e.g
    DataMaster.insertData()
    DataSummary.insertData()

    4.1 Parameter initialization for data table creation 

5.Create Table data
    e.g
    Query.createTable("TBL_DATA")
    
6.Insert Table Data
    e.g
    Data.insertData()
    
7.Create Context Mapping Table 
    e.g 
    ContextMapping.createContextMappingTable()

8.Apply Context Setting Rule 
    e.g 
    ContextMapping.ruleInsertion(context_mapping_id,rule_number)

    8.1 Store the context mapping tabble in data base 
    e.g
    ContextMapping.setContextMappingToDataBase()

9.Sort Context Mapping Table by user provided context id and then see the final result table 
    e.g 
    ContextMapping.sortContextMappigTable(context_id)


Good Luck
"""


###Initialization of Parameters
Global_vars.GEINE = openpyxl.load_workbook("TBL_GEINE.xlsx")
Global_vars.GEINE_DATA = openpyxl.load_workbook("TBL_DATA.xlsx")
Global_vars.Table={}
Global_vars.Table["TBL_DOMAIN"]=0
Global_vars.Table["TBL_CONTEXT"]=1
Global_vars.Table["TBL_FEATURES"]=2
Global_vars.Table["TBL_CONTEXT_SETTING_RULE"]=3
Global_vars.Table["TBL_DATA_MASTER"]=4
Global_vars.Table["TBL_DATA"]=5
Global_vars.Table["TBL_DATA_SUMMARY"]=6
Global_vars.Data_SUMMARY_ID=[]
Global_vars.Data_Parameter_Name=[]
Global_vars.Data_Table_Name=[]
Global_vars.Data_Parameter_Types=[]


# Step-1
# Query.createTable("TBL_DOMAIN","TBL_FEATURES","TBL_CONTEXT","TBL_CONTEXT_SETTING_RULE")
Domain.insertData()
Feature.insertData()
# Context.insertData()
# ContextRuleSetting.insertData()

# Step-2
# Query.createTable("TBL_DATA_MASTER","TBL_DATA_SUMMARY")
# DataMaster.insertData()
# DataSummary.insertData()


# ParameterStep3.parameterInitialize()

# print(Global_vars.Data_Parameter_Name)

# Step-3
# Query.createTable("TBL_DATA")
# Data.insertData()

# Step-4
# ContextMapping.createContextMappingTable()
# ContextMapping.ruleInsertion(1,1,2)
# ContextMapping.ruleInsertion(3,2)
# ContextMapping.setContextMappingToDataBase()
# print(Global_vars.context_maaping_table.columns)
# print(Global_vars.context_maaping_table['tbl_name'])
# ContextMapping.sortContextMappigTable(1,2,3)
# ContextMapping.sortContextMappigTable(2)


# mycursor = Connection.Connection.conn.cursor()
#
# filename = "Data1"
# print('FileName:', filename)
#
# mycursor.execute(f"drop table '" +str(filename) + "'")

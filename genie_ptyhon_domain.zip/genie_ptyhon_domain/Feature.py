import openpyxl

import Query


class Feature:
    def __init__(self,Feature_ID,Domain_ID,Feature_Name,Feature_Description):
        self.Feature_ID=Feature_ID
        self.Domain_ID=Domain_ID
        self.Feature_Name=Feature_Name
        self.Feature_Description=Feature_Description

    def __str__(self):
        return "Feature_ID = {}, Context_ID = {}, Feature_Name = {}, Feature_Description = {}".format(self.Feature_ID,self.Context_ID,self.Feature_Name,self.Feature_Description)

    @staticmethod
    def insertData():
        C = []
        TBL_GEINE = openpyxl.load_workbook("TBL_GEINE.xlsx")
        A = TBL_GEINE["TBL_FEATURES"]
        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                # print(C)
                C.append(Feature(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value,
                                 A.cell(i + 3, 4).value))
                i += 1
            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_FEATURES", C[i].Feature_ID, C[i].Domain_ID, C[i].Feature_Name,
                                           C[i].Feature_Description)
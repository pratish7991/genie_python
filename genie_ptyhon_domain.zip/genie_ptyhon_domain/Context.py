import openpyxl

import Global_vars
import Query

# A context class with table name as its arguments
class Context:
    def __init__(self,Context_ID,Domain_ID,Context_Name,Context_Description):
        self.Context_ID=Context_ID
        self.Domain_ID=Domain_ID
        self.Context_Name=Context_Name
        self.Context_Description=Context_Description

    def __str__(self):
        return "Context_ID = {}, Domain_ID = {}, Context_Name = {}, Context_Description = {}".format(self.Context_ID,self.Domain_ID,self.Context_Name,self.Context_Description)

    # This method extract data of context from excel file and store it into an object and then upload its elements of this object in postgres sql
    @staticmethod
    def insertData():
        C = []
        A = Global_vars.GEINE["TBL_CONTEXT"]
        i = 0
        while True:
            if A.cell(i + 3, 1).value is not None:
                C.append(Context(A.cell(i + 3, 1).value, A.cell(i + 3, 2).value, A.cell(i + 3, 3).value,
                                         A.cell(i + 3, 4).value))
                i += 1

            else:
                break
        for i in range(len(C)):
            Query.insertTable("TBL_CONTEXT", C[i].Context_ID, C[i].Domain_ID, C[i].Context_Name,
                                           C[i].Context_Description)
